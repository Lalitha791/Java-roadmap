public class Main {
    public static void main(String[] args) {
        System.out.println("Main method");
        welcomeMessage();
    }

    public static void welcomeMessage() {
        System.out.println("Welcome to Java");
    }
}
