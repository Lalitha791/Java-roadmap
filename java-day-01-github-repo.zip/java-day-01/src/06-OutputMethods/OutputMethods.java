public class OutputMethods {
    public static void main(String[] args) {
        System.out.print("Hello ");
        System.out.print("Java ");
        System.out.println("World");

        String name = "Lalitha";
        int age = 22;
        double percentage = 85.567;

        System.out.printf("Name: %s%n", name);
        System.out.printf("Age: %d%n", age);
        System.out.printf("Percentage: %.2f%n", percentage);
    }
}
