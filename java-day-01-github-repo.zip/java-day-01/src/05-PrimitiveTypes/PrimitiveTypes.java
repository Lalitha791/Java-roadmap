public class PrimitiveTypes {
    public static void main(String[] args) {
        byte smallNumber = 100;
        short year = 2026;
        int marks = 95;
        long population = 8000000000L;
        float price = 99.5f;
        double percentage = 85.75;
        char grade = 'A';
        boolean passed = true;

        System.out.println(smallNumber);
        System.out.println(year);
        System.out.println(marks);
        System.out.println(population);
        System.out.println(price);
        System.out.println(percentage);
        System.out.println(grade);
        System.out.println(passed);
    }
}
