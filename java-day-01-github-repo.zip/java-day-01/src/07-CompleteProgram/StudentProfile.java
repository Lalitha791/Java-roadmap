public class StudentProfile {
    public static void main(String[] args) {
        // Student information
        String name = "Lalitha";
        int age = 22;
        double percentage = 85.75;
        char grade = 'A';
        boolean graduated = true;

        // Display student information
        System.out.println("STUDENT DETAILS");
        System.out.println("----------------");
        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.printf("Percentage: %.2f%n", percentage);
        System.out.println("Grade: " + grade);
        System.out.println("Graduated: " + graduated);
    }
}
