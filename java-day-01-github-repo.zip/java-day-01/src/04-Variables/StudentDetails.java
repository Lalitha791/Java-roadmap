public class StudentDetails {
    public static void main(String[] args) {
        String name = "Lalitha";
        int age = 22;
        double percentage = 85.5;
        char grade = 'A';
        boolean graduated = true;

        System.out.println("Name: " + name);
        System.out.println("Age: " + age);
        System.out.println("Percentage: " + percentage);
        System.out.println("Grade: " + grade);
        System.out.println("Graduated: " + graduated);
    }
}
