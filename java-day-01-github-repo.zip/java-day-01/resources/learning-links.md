# Day 1 – Free Learning and Practice Resources

Use one video source, one written reference and one coding platform. You do not need to watch multiple explanations of the same topic.

## Main video course
- [Telusko – Java beginner course](https://www.youtube.com/watch?v=BGTx91t8q50)
- [Bro Code – Java full course](https://www.youtube.com/watch?v=xTtL8E4LzTQ)

## Official reference
- [Dev.java learning portal](https://dev.java/learn/)
- [Your first Java code](https://dev.java/learn/first-steps/first-java-code/)
- [Java language basics](https://dev.java/learn/language-basics/)

## Written tutorials
- [W3Schools Java tutorial](https://www.w3schools.com/java/)
- [Java syntax](https://www.w3schools.com/java/java_syntax.asp)
- [Java variables](https://www.w3schools.com/java/java_variables.asp)
- [Java data types](https://www.w3schools.com/java/java_data_types.asp)
- [Java output](https://www.w3schools.com/java/java_output.asp)

## HackerRank practice
1. [Welcome to Java!](https://www.hackerrank.com/challenges/welcome-to-java/problem)
2. [Java Stdin and Stdout I](https://www.hackerrank.com/challenges/java-stdin-and-stdout-1/problem) – preview of input, which is covered later.
3. [Java Datatypes](https://www.hackerrank.com/challenges/java-datatypes/problem)
4. [Java Output Formatting](https://www.hackerrank.com/challenges/java-output-formatting/problem)

## Suggested timetable
| Time | Task |
|---|---|
| 20 min | Java introduction and JDK/JRE/JVM |
| 30 min | Program structure and `main()` |
| 30 min | Variables and data types |
| 15 min | Output methods |
| 35 min | Coding assignments |
| 20 min | Assessment questions |
