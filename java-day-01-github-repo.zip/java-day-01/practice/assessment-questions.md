# Day 1 Assessment Questions

Try answering without checking the notes.

1. Explain why Java is platform independent.
2. What is the difference between JDK, JRE and JVM?
3. What is bytecode?
4. What does `static` mean in the main method?
5. What is the difference between primitive and reference data types?
6. What happens if you use `Age` instead of `age`?
7. What is the difference between `print()` and `println()`?
8. Why do we use `final`?
9. What is the difference between `.java` and `.class`?
10. What happens if you declare a local variable without initializing it and try to use it?

## Self-check
- [ ] I can explain each answer in my own words.
- [ ] I can write the basic Java program structure from memory.
- [ ] I can identify and correct common syntax mistakes.
