# Day 1 Coding Assignments

Complete in order. Type and run each program yourself.

## Level 1 – Basic printing
- [ ] 1. Print `Hello World`.
- [ ] 2. Print your full name.
- [ ] 3. Print your college name.
- [ ] 4. Print five different lines.
- [ ] 5. Print your details using `printf()`.

## Level 2 – Variables and data types
- [ ] 6. Declare an integer variable and print it.
- [ ] 7. Declare a double variable and print it.
- [ ] 8. Store your name, age and graduation year.
- [ ] 9. Store a character grade and boolean result.
- [ ] 10. Declare and print all eight primitive data types.

## Level 3 – Program structure
- [ ] 11. Create a class named `Student`.
- [ ] 12. Create a class named `Employee`.
- [ ] 13. Create a second static method and call it from `main()`.
- [ ] 14. Print messages using `print`, `println` and `printf`.
- [ ] 15. Write a complete student information program.

## Submission convention
Save each solution in a clearly named folder or file. Add a short comment describing the task. Commit your work after completing the day.
