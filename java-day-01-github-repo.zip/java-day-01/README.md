# Java Day 1 – Introduction to Java

**Track:** Core Java + DSA  
**Goal:** Build a strong Java foundation for Infosys Systems Engineer assessments and interviews.  
**Level:** Beginner  
**Study time:** Approximately 2 hours 30 minutes

## Day 1 syllabus
1. What is Java?
2. JDK vs JRE vs JVM
3. Java program structure
4. `main()` method
5. Variables and data types
6. Output: `print()`, `println()`, `printf()`
7. Java comments

## Repository layout
```text
java-day-01/
├── README.md
├── notes/
│   └── day-01-notes.md
├── src/
│   ├── 01-HelloWorld/
│   │   └── Main.java
│   ├── 02-ProgramStructure/
│   │   └── Student.java
│   ├── 03-MainMethod/
│   │   └── Main.java
│   ├── 04-Variables/
│   │   └── StudentDetails.java
│   ├── 05-PrimitiveTypes/
│   │   └── PrimitiveTypes.java
│   ├── 06-OutputMethods/
│   │   └── OutputMethods.java
│   └── 07-CompleteProgram/
│       └── StudentProfile.java
├── practice/
│   ├── assignments.md
│   └── assessment-questions.md
└── resources/
    └── learning-links.md
```

## How to run
Install a JDK, then open a terminal in the folder containing the Java file.

```bash
javac Main.java
java Main
```

For a file with a different public class name, use that name:
```bash
javac StudentDetails.java
java StudentDetails
```

## Learning workflow
- Read `notes/day-01-notes.md`.
- Type each program yourself; do not just copy and paste.
- Run the programs and compare your output.
- Complete `practice/assignments.md`.
- Answer `practice/assessment-questions.md` without looking at the notes.
- Attempt the HackerRank exercises in `resources/learning-links.md`.

## Day 1 completion checklist
- [ ] Explain Java and platform independence.
- [ ] Explain JDK, JRE and JVM.
- [ ] Create and run a Java class.
- [ ] Explain every part of `main()`.
- [ ] Declare and initialize variables.
- [ ] Use all eight primitive data types.
- [ ] Explain reference types and default values.
- [ ] Use `print()`, `println()` and `printf()`.
- [ ] Complete at least 10 assignments.
- [ ] Solve HackerRank: Welcome to Java.

## Git commands
```bash
git init
git add .
git commit -m "Add Java Day 1 fundamentals"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/java-day-01.git
git push -u origin main
```

Replace `YOUR-USERNAME` with your GitHub username.
