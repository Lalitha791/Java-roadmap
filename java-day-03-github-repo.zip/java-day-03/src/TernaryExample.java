public class TernaryExample {
    public static void main(String[] args) {
        int age = 20;
        String result = age >= 18 ? "Eligible" : "Not eligible";

        System.out.println(result);
    }
}
