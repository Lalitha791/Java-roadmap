public class IncrementDecrement {
    public static void main(String[] args) {
        int x = 5;

        System.out.println("Post-increment: " + x++);
        System.out.println("After post-increment: " + x);
        System.out.println("Pre-increment: " + ++x);
        System.out.println("Post-decrement: " + x--);
        System.out.println("After post-decrement: " + x);
        System.out.println("Pre-decrement: " + --x);
    }
}
