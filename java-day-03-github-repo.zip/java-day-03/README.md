# Core Java – Day 3: Operators

This repository contains notes, examples and practice tasks for Java operators.

## Topics covered
- Arithmetic operators: `+`, `-`, `*`, `/`, `%`
- Relational operators: `==`, `!=`, `>`, `<`, `>=`, `<=`
- Logical operators: `&&`, `||`, `!`
- Assignment operators: `=`, `+=`, `-=`, `*=`, `/=`, `%=`
- Unary operators: `++`, `--`
- Ternary operator: `? :`
- Operator precedence and associativity
- Basic bitwise and shift operators (reference)

## Folder structure
```text
java-day-03/
├── README.md
├── notes/
│   └── day-03-notes.md
├── src/
│   ├── ArithmeticExample.java
│   ├── RelationalExample.java
│   ├── LogicalExample.java
│   ├── AssignmentExample.java
│   ├── IncrementDecrement.java
│   ├── TernaryExample.java
│   └── OperatorPrecedence.java
└── practice/
    ├── assignments.md
    └── assessment-questions.md
```

## How to run
Open a terminal in the folder containing a Java file:
```bash
javac ArithmeticExample.java
java ArithmeticExample
```

## Progress checklist
- [ ] Read the notes
- [ ] Type and run all example programs
- [ ] Complete the assignments
- [ ] Answer the assessment questions
- [ ] Revise Day 1–3

**Suggested commit message:** `Day 3: Added Java operators notes and practice programs`
